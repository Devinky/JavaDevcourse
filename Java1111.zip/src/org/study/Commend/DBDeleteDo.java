package org.study.Commend;

public class DBDeleteDo extends SQLQueryCommend{

	@Override
	public void excuteQueryCommend() {
		System.out.println("회원탈퇴");
	}

}
