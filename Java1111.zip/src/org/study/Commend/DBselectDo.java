package org.study.Commend;

public class DBselectDo extends SQLQueryCommend {

	@Override
	public void excuteQueryCommend() {
		System.out.println("회원조회");
	}
	
}
