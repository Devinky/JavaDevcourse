package org.study.Commend;

public abstract class SQLQueryCommend {
	
	public abstract void excuteQueryCommend();

}
