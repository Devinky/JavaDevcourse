package org.study.Polymorphism;

public class Parent {
	
	public void excuteQueryCommend() {
		System.out.println("부모 Parent");
	}

}
