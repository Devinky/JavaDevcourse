package org.study.Polymorphism;

public class MainClass {
	
	public static void main(String[] args) {
		Parent p1 = new Sub01();
		p1.excuteQueryCommend();
		
		p1 = new Sub02();
		p1.excuteQueryCommend();
		
		int i = 10;
		i = 390;
		
	}

}
