package org.study.abstractEX;

public abstract class AbstractEX01 {
	
	int num1;
	int num2;
	
	//추상메서드
	public abstract void abstractMethod(); //abstract메서드(선언부만 있고 구현부가 없음. 미완성 메서드)

}
