package org.study.abstractEX;

public class Abstract01Sub01SubSub extends Abstract01Sub01Sub {

	@Override
	public void abstractM1() {
		System.out.println("추상메서드 오버라이드1");
	}
	@Override
	public void abstractM2(String name) {
		System.out.println(name);
	}
	@Override
	public void abstractM3() {
		System.out.println("추상메서드 오버라이드 3");
	}


	
	
}
