package org.study.abstractEX;

public abstract class AbstractEX01Sub02 extends AbstractEX01 {
	
	public abstract void abstractMethod2();

}
