package org.study.abstractEX;

public class AbstractEX01Sub02Sub extends AbstractEX01Sub02 {

	@Override
	public void abstractMethod2() {
		System.out.println("추상매서드1");
	}

	@Override
	public void abstractMethod() {
		System.out.println("추상매서드2");
		
	}
	

	

}
