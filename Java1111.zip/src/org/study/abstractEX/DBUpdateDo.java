package org.study.abstractEX;

public class DBUpdateDo extends SQLQueryCommend{

	@Override
	public void excuteQueryCommend() {
		System.out.println("회원수정");
	}

}
