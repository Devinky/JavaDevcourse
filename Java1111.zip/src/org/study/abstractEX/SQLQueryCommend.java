package org.study.abstractEX;

public abstract class SQLQueryCommend {
	
	public abstract void excuteQueryCommend();

}
