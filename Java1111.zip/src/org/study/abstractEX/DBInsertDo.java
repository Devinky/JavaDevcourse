package org.study.abstractEX;

public class DBInsertDo extends SQLQueryCommend {

	@Override
	public void excuteQueryCommend() {
		System.out.println("회원가입");
	}

}
