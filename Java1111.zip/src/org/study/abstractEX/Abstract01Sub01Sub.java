package org.study.abstractEX;

public abstract class Abstract01Sub01Sub extends Abstract01Sub01 {
	
	public abstract void abstractM3();

}
