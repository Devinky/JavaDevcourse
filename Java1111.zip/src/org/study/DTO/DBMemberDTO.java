package org.study.DTO;

public class DBMemberDTO {

}
