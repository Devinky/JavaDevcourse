package org.study.commend;

public class MemberDeleteDo implements ExcuteCommend {

	@Override
	public void excuteCommend() {
		System.out.println("회원탈퇴");
	}
	

}
