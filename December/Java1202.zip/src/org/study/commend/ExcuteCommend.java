package org.study.commend;

public interface ExcuteCommend {
	
	void excuteCommend();

}
