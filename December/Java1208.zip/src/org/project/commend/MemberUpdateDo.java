package org.project.commend;

public class MemberUpdateDo implements MemberCommend {

	@Override
	public void excuteQueryCommend() {
		System.out.println("회원정보 수정");
	}

}
