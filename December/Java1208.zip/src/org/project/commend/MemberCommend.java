package org.project.commend;

public interface MemberCommend {
	
	void excuteQueryCommend();

}
